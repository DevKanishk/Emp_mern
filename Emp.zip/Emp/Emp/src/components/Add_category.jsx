import axios from 'axios'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const AddCategory = () => {
    const [category, setCategory] = useState('')
    const [error, setError] = useState('')
    const navigate = useNavigate()

    const handleSubmit = (e) => {
        e.preventDefault()
        
        if (!category.trim()) {
            setError('Category name is required.')
            return
        }

        axios.post('http://localhost:3000/auth/add_category', { category })
            .then(result => {
                if (result.data.Status) {
                    navigate('/dashboard/category')
                } else {
                    setError(result.data.Error || 'Something went wrong.')
                }
            })
            .catch(err => {
                setError('An error occurred while adding the category.')
                console.log(err)
            })
    }

    return (
        <div className='d-flex justify-content-center align-items-center h-100'>
            <div className='p-3 rounded w-50 border'>
                <h2 className='text-center mb-4'>Add Category</h2>
                {error && <div className="alert alert-danger" role="alert">{error}</div>}
                <form onSubmit={handleSubmit}>
                    <div className='mb-3'>
                        <label htmlFor="category" className='form-label'><strong>Category:</strong></label>
                        <input type="text" name='category' placeholder='Enter Category'
                            value={category} onChange={(e) => setCategory(e.target.value)} className='form-control' />
                    </div>
                    <button type="submit" className='btn btn-success w-100'>Add Category</button>
                </form>
            </div>
        </div>
    )
}

export default AddCategory
